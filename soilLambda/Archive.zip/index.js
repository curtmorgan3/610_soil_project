let aws = require("aws-sdk");
let nodemailer = require("nodemailer");

let ses = new aws.SES();

exports.handler = (event, context, callback) => {

    const mailOptions = {
        from: "curtmorgan3@gmail.com",
        subject: "Test",
        html: `<p>You got a contact message from: <b>${event.emailAddress}</b></p>`,
        to: "curtmorgan3@gmail.com"
    };

    // create Nodemailer SES transporter
    const transporter = nodemailer.createTransport({
        SES: ses
    });

    // send email
    transporter.sendMail(mailOptions, (err, info) => {
        if (err) {
            console.log("Error sending email");
            callback(err);
        } else {
            console.log("Email sent successfully");
            callback();
        }
    });
    callback(null, 'Hello from Lambda');
};
